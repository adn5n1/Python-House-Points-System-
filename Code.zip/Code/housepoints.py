from guizero import App, Text, TextBox, PushButton, Window, Combo, ListBox, info, error  # type: ignore
import json
import os

class HousePointsApp:
    def __init__(self):
        self.app = App(title="House Points System", width=400, height=300)
        self.teacher_data = self.load_data("teachers.json", "teachers")
        self.student_data = self.load_data("students.json", "students")
        self.create_login_screen()
        self.app.display()

    def load_data(self, file_path, key):
        if os.path.exists(file_path) and os.stat(file_path).st_size > 0:
            with open(file_path) as file:
                data = json.load(file)
                return data.get(key, [])
        return []

    def save_students(self):
        with open("students.json", "w") as f:
            json.dump({"students": self.student_data}, f, indent=4)

    def create_login_screen(self):
        self.app.title = "Teacher Login"
        for widget in self.app.children:
            widget.hide()

        Text(self.app, text="Username:")
        self.username_input = TextBox(self.app)
        Text(self.app, text="Password:")
        self.password_input = TextBox(self.app, hide_text=True)
        PushButton(self.app, text="Login", command=self.check_login)
        PushButton(self.app, text="Leaderboard", command=self.show_leaderboard)

    def check_login(self):
        username = self.username_input.value
        password = self.password_input.value

        for teacher in self.teacher_data:
            if teacher["username"] == username and teacher["password"] == password:
                self.show_main_menu()
                return

        error("Login Failed", "Incorrect username or password.")

    def show_main_menu(self):
        self.clear_app()
        self.app.title = "Teacher Main Menu"
        Text(self.app, text="Welcome to House Points System")
        PushButton(self.app, text="Add Student", command=self.show_add_student)
        PushButton(self.app, text="Add Points", command=self.show_add_points)
        PushButton(self.app, text="Leaderboard", command=self.show_leaderboard)
        PushButton(self.app, text="Logout", command=self.create_login_screen)

    def show_add_student(self):
        self.clear_app()
        self.app.title = "Add Student"
        Text(self.app, text="First Name:")
        self.first_name_input = TextBox(self.app)
        Text(self.app, text="Surname:")
        self.last_name_input = TextBox(self.app)
        Text(self.app, text="Username:")
        self.student_username = TextBox(self.app)
        Text(self.app, text="Password:")
        self.student_password = TextBox(self.app)
        PushButton(self.app, text="Submit", command=self.add_student)
        PushButton(self.app, text="Back", command=self.show_main_menu)

    def add_student(self):
        new_student = {
            "forename": self.first_name_input.value,
            "surname": self.last_name_input.value,
            "username": self.student_username.value,
            "password": self.student_password.value,
            "points": 0
        }
        self.student_data.append(new_student)
        self.save_students()
        info("Success", "Student added successfully.")

    def show_add_points(self):
        self.clear_app()
        self.app.title = "Add Points"
        Text(self.app, text="Select Student:")
        self.student_list = ListBox(self.app, items=self.get_student_names())
        Text(self.app, text="Points to add:")
        self.points_combo = Combo(self.app, options=["1", "2", "3", "5", "10"])
        PushButton(self.app, text="Add Points", command=self.add_points)
        PushButton(self.app, text="Back", command=self.show_main_menu)

    def get_student_names(self):
        return [f"{s['forename']} {s['surname']}" for s in self.student_data]

    def add_points(self):
        selected_name = self.student_list.value
        if selected_name and self.points_combo.value:
            for student in self.student_data:
                full_name = f"{student['forename']} {student['surname']}"
                if full_name == selected_name:
                    student["points"] += int(self.points_combo.value)
                    self.save_students()
                    info("Success", "Points added successfully.")
                    return
            error("Error", "Student not found.")
        else:
            error("Input Error", "Please select a student and number of points.")

    def show_leaderboard(self):
        self.clear_app()
        self.app.title = "Leaderboard"
        Text(self.app, text="Leaderboard - Top Scoring Students")
        sorted_students = sorted(self.student_data, key=lambda x: x["points"], reverse=True)
        for student in sorted_students:
            Text(self.app, text=f"{student['forename']} {student['surname']}: {student['points']} points")
        PushButton(self.app, text="Back", command=self.create_login_screen)

    def clear_app(self):
        for widget in self.app.children:
            widget.destroy()

HousePointsApp()