This code has been refactored to use guizero (an alternative to pysimplegui).  It hasn't been tested so it's probably got bugs! But you can find guizero docs online.

Extract these files before running the program.

This starter code is just that, a starting point.  It is not a completed, fully working program.  You can change anything you like about how it works, or it's appearance.  It is a suggestion of how you can structure your program so it is modular (each process has it's own function).

The starter code contains lots of comments to help you understand how it works.  If you are still unsure what something does, change it and see what happens.  If still in doubt, seek support.

Use comments in your own code because you can get lost in your own code.  Please make frequent backups as you develop your program. Programming is all about problem-solving and you WILL have problems. Read error messages for line numbers and remember that it is often the smallest typos that can cause a program to crash.